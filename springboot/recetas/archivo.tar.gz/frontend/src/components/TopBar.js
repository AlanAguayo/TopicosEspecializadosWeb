import React from "react";

const TopBar = ({ }) => {
    return (
        <a href="/" className="text-2xl font-bold mb-4 text-center block bg-blue-100 p-4">
            <div className="flex items-center justify-center">
                Practica 1. Competencia 2.
            </div>
        </a>

    );
};

export default TopBar;